class Account:
	name = None
	clientID = None
	clientSecret = None
	accessToken = None
	refreshToken = None
	expiry = None
	driveStream = None
	key = None
	email = None
